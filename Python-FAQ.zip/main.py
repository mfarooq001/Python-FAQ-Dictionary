finished = False
diction={}

while not finished:
  exit = print("0: Exit ")
  sofar=print("1: List FAQ's")
  add=print("2: Add FAQ")
  hitolo=print("3: Delete FAQ")
  selection=input("Please enter a selection 1 to 4:")

  if selection == '0':
    print("Done!")
    break;

  if selection == '2':
    ques=input("Please enter the question:")
    ans=input("Please enter the answer:")
    diction[ques]=ans
    print("Your FAQ has been added")
  
  if selection == '1':
    print("FREQUENTLY ASKED QUESTIONS")
    print("==========================")
    quesprint = print("Question: {}".format(ques))
    ansprint = print("Answer: {}".format(ans))
  
  if selection == '3':
    delet=input("Please enter the question to delete:")
    del diction[delet]
    print("{} has been deleted from the FAQ".format(delet))


  
